import num2words
for i in range (0,101,10):
 for j in range(i,i+9):
  if j<=100:
   print (j,end=" ")
  else:
   break
 if i<=100:
  print(num2words(i+9, to='ordinal'))