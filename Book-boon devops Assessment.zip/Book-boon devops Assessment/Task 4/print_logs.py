from time import sleep

while True:
    print("Bookboon test")
    sleep(1)
	
	
